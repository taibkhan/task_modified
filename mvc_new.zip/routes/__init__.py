from . import mongo_insertion
__all__ = [mongo_insertion]