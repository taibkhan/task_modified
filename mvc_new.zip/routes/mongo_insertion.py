from flask import Blueprint
from flask import request
from flask import jsonify
import pprint
from controller import controller
obj=controller()
bp=Blueprint(__name__,"mongo_insertion")
@bp.route('/insert', methods=['POST'])
def insert():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    address=data['address']
    flag=obj.check(username)
    #calling insert method of controller
    if(flag==0):
        result=obj.insert(username,address)
        result1=obj.show_db()
        respo={"DATABASE":result1, "USER INSERTED":result}
        return jsonify(respo)
    else:
        return 'username already exist'


@bp.route('/delete', methods=['POST'])
def delete():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    #calling delete method of controller
    flag=obj.check(username)
    if(flag==1):
        obj.delete(username)
        return "user deleted"
    else:
        return "username doesnt exist"



@bp.route("/display", methods=['GET'])
def show_db():
    result=obj.show_db()
    return jsonify(result)



@bp.route('/update',methods=['POST'])
def update():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    updatedaddress=data['updatedaddress']
    #calling update method of controller
    flag=obj.check(username)
    if(flag==1):
        obj.update(username,updatedaddress)
        result=obj.show_db()
        return jsonify(result)
    else:
        return "username doesn't exist"