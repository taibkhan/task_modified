from model.base import db, employees
import json
class controller(object):
	def insert(self, username, address):
		employee={
			'username':username,
			'address':address
			}
	
		employees.insert_one(employee)
		employee['_id']=str(employee['_id'])
		return employee
	
	
	def check(self, username):
		results=employees.count_documents({
			'username':username
		})   
		if(results>0):
			return 1
		else:
			return 0
	
	def delete(self, username):
		employees.delete_one({'username':username})

	def show_db(self):
		employess=list(employees.find())
		for emp in employess:
			emp['_id']=str(emp['_id'])
		return employess
		 
		 
	def update(self,username,updatedaddress):
		employees.update_one( 
			{"username":username}, 
			{ 
					"$set":{ 
							"address":updatedaddress
							}
					}
			)