import routes
from flask import Flask
from model.base import db

def create_app():
    app = Flask(__name__)
    app.register_blueprint(routes.mongo_insertion.bp)
    app.debug = True
    return app